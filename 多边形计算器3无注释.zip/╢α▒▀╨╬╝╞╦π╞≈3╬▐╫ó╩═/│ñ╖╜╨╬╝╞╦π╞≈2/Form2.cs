﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 长方形计算器2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 fm1 = new Form1();
            this.Hide();
            fm1.Show();
        }//回到主界面

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Text = "使用须知：" +
                "1、请不要输入过大的数据。" +
                "2、请不要输入错误的字符。" +
                "3、请不要在工程计算中试图用该产品，请寻找精确度更高的计算器使用。";
        }
    }
}
